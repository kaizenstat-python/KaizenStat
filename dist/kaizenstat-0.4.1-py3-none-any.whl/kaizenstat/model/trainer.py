"""Model benchmarking and training engine."""
from __future__ import annotations

import time
import warnings
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    mean_absolute_error,
    r2_score,
    roc_auc_score,
)
from sklearn.model_selection import (
    StratifiedKFold, KFold, cross_val_score, train_test_split, RandomizedSearchCV,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.ensemble import (
    GradientBoostingClassifier,
    GradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)

from kaizenstat.utils.helpers import (
    detect_task_type,
    get_categorical_cols,
    get_numeric_cols,
    validate_dataframe,
)

warnings.filterwarnings("ignore")
console = Console()

# Hyperparameter search spaces — keyed by model name from _get_models()
_PARAM_GRIDS: Dict[str, Dict] = {
    "LogisticRegression": {
        "model__C": [0.01, 0.1, 1, 10, 100],
        "model__solver": ["lbfgs", "saga"],
    },
    "RandomForest": {
        "model__n_estimators": [50, 100, 200, 300],
        "model__max_depth": [None, 5, 10, 20],
        "model__min_samples_leaf": [1, 2, 5],
        "model__max_features": ["sqrt", "log2"],
    },
    "GradientBoosting": {
        "model__n_estimators": [50, 100, 200],
        "model__learning_rate": [0.05, 0.1, 0.2],
        "model__max_depth": [3, 5, 7],
        "model__subsample": [0.8, 1.0],
    },
    "XGBoost": {
        "model__n_estimators": [50, 100, 200],
        "model__learning_rate": [0.05, 0.1, 0.2],
        "model__max_depth": [3, 5, 7],
        "model__subsample": [0.8, 1.0],
        "model__colsample_bytree": [0.8, 1.0],
    },
    "LightGBM": {
        "model__n_estimators": [50, 100, 200],
        "model__learning_rate": [0.05, 0.1, 0.2],
        "model__num_leaves": [15, 31, 63],
        "model__subsample": [0.8, 1.0],
    },
    "Ridge": {
        "model__alpha": [0.01, 0.1, 1, 10, 100],
    },
}


@dataclass
class ModelEntry:
    name: str
    score: float
    std: float
    train_time: float
    metric: str
    error: Optional[str] = None


@dataclass
class BenchmarkResult:
    task: str                  # classification / regression
    metric: str
    entries: List[ModelEntry]
    best_name: str
    best_score: float
    best_pipeline: Optional[Any] = None
    label_encoder: Optional[Any] = None

    def display(self) -> None:
        console.print(Panel.fit(
            f"[bold cyan]Task: {self.task.upper()}[/bold cyan]  │  "
            f"Metric: {self.metric}  │  "
            f"Best: [bold green]{self.best_name}[/bold green] ({self.best_score:.4f})",
            title="[bold]KaizenStat · Model Benchmark[/bold]",
            border_style="cyan",
        ))

        table = Table(box=box.ROUNDED, header_style="bold magenta")
        table.add_column("Rank", justify="center", width=6)
        table.add_column("Model", style="cyan")
        table.add_column("Score", justify="right", style="bold green")
        table.add_column("± Std", justify="right", style="dim")
        table.add_column("Time(s)", justify="right", style="yellow")

        medals = ["🥇", "🥈", "🥉"]
        for i, e in enumerate(sorted(self.entries, key=lambda x: x.score, reverse=True)):
            rank = medals[i] if i < 3 else f"#{i + 1}"
            score_str = f"{e.score:.4f}" if e.error is None else "[red]ERROR[/red]"
            table.add_row(rank, e.name, score_str, f"± {e.std:.4f}", f"{e.train_time:.2f}s")
        console.print(table)
        console.print()


@dataclass
class TrainResult:
    model_name: str
    task: str
    train_score: float
    test_score: float
    metrics: Dict[str, float]
    pipeline: Any
    label_encoder: Optional[Any] = None
    feature_names: List[str] = field(default_factory=list)
    cv_score: float = 0.0
    cv_std: float = 0.0
    best_params: Dict[str, Any] = field(default_factory=dict)

    def display(self) -> None:
        tuned = f"  │  [bold magenta]Tuned ✓[/bold magenta]" if self.best_params else ""
        cv_line = (f"CV Score: [cyan]{self.cv_score:.4f}[/cyan] ± {self.cv_std:.4f}  │  " if self.cv_score else "")
        console.print(Panel.fit(
            f"[bold cyan]{self.model_name}[/bold cyan]  │  Task: {self.task}{tuned}\n"
            f"{cv_line}"
            f"Train: [green]{self.train_score:.4f}[/green]  │  "
            f"Test:  [bold green]{self.test_score:.4f}[/bold green]",
            title="[bold]KaizenStat · Train Result[/bold]",
            border_style="cyan",
        ))
        if self.metrics:
            for k, v in self.metrics.items():
                console.print(f"  [cyan]{k}:[/cyan] {v:.4f}")
        if self.best_params:
            console.print("  [bold magenta]Best params:[/bold magenta]")
            for k, v in self.best_params.items():
                console.print(f"    {k.replace('model__', '')}: {v}")
        console.print()


class ModelTrainer:
    """Benchmarks and trains ML models with automatic preprocessing."""

    def benchmark(
        self,
        df: pd.DataFrame,
        target: str,
        cv: int = 5,
        extra_models: Optional[Dict[str, Any]] = None,
    ) -> BenchmarkResult:
        validate_dataframe(df, target)
        X, y, task, le = self._prepare(df, target)
        metric = self._select_metric(task, y)
        models = self._get_models(task, y, extra_models=extra_models)
        preprocessor = self._build_preprocessor(X)
        n_cv = min(cv, max(2, len(X) // 50))

        entries: List[ModelEntry] = []
        best_score = -np.inf
        best_pipeline = None

        for name, model in models.items():
            pipe = Pipeline([("prep", preprocessor), ("model", model)])
            with Progress(SpinnerColumn(), TextColumn(f"Training [cyan]{name}[/cyan]..."),
                          console=console, transient=True) as prog:
                prog.add_task("", total=None)
                t0 = time.time()
                try:
                    cv_obj = (
                        StratifiedKFold(n_splits=n_cv, shuffle=True, random_state=42)
                        if task == "classification" else
                        KFold(n_splits=n_cv, shuffle=True, random_state=42)
                    )
                    scores = cross_val_score(pipe, X, y, cv=cv_obj, scoring=metric, n_jobs=-1)
                    elapsed = time.time() - t0
                    mean_score = float(scores.mean())

                    if mean_score > best_score:
                        best_score = mean_score
                        pipe.fit(X, y)
                        best_pipeline = pipe

                    entries.append(ModelEntry(
                        name=name, score=round(mean_score, 4),
                        std=round(float(scores.std()), 4),
                        train_time=round(elapsed, 2),
                        metric=metric,
                    ))
                except Exception as exc:
                    entries.append(ModelEntry(
                        name=name, score=0.0, std=0.0,
                        train_time=round(time.time() - t0, 2),
                        metric=metric, error=str(exc)[:80],
                    ))

        best = max(entries, key=lambda e: e.score)
        result = BenchmarkResult(
            task=task, metric=metric, entries=entries,
            best_name=best.name, best_score=best.score,
            best_pipeline=best_pipeline, label_encoder=le,
        )
        result.display()
        return result

    def train_best(
        self,
        df: pd.DataFrame,
        target: str,
        test_size: float = 0.2,
        cv: int = 5,
        tune: bool = False,
        n_iter: int = 20,
        extra_models: Optional[Dict[str, Any]] = None,
    ) -> TrainResult:
        validate_dataframe(df, target)
        X, y, task, le = self._prepare(df, target)

        # Split FIRST so the benchmark only sees training data.
        # Fitting benchmark on full data then scoring on the split would cause
        # test-set contamination (X_test rows already seen during fit → inflated scores).
        try:
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size,
                stratify=y if task == "classification" else None,
                random_state=42,
            )
        except ValueError:
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, random_state=42
            )

        # Reconstruct a training-only DataFrame to pass to benchmark
        train_df = X_train.copy()
        train_df[target] = y_train.values

        bm = self.benchmark(train_df, target, cv=cv, extra_models=extra_models)
        if bm.best_pipeline is None:
            raise RuntimeError("No model was successfully trained during benchmark.")

        # Find the CV score for the best model entry
        best_entry = next((e for e in bm.entries if e.name == bm.best_name), None)
        cv_score = best_entry.score if best_entry else 0.0
        cv_std   = best_entry.std   if best_entry else 0.0

        pipe        = bm.best_pipeline
        best_params = {}

        # Optional hyperparameter tuning via RandomizedSearchCV
        if tune and bm.best_name in _PARAM_GRIDS:
            param_grid = _PARAM_GRIDS[bm.best_name]
            metric     = bm.metric
            cv_obj     = (
                StratifiedKFold(n_splits=min(cv, 5), shuffle=True, random_state=42)
                if task == "classification" else
                KFold(n_splits=min(cv, 5), shuffle=True, random_state=42)
            )
            console.print(f"[bold magenta]Tuning {bm.best_name} "
                          f"(n_iter={n_iter}, cv={cv_obj.n_splits})…[/bold magenta]")
            with Progress(SpinnerColumn(), TextColumn("Searching hyperparameters…"),
                          console=console, transient=True) as prog:
                prog.add_task("", total=None)
                search = RandomizedSearchCV(
                    pipe, param_grid,
                    n_iter=min(n_iter, len(list(param_grid.values())[0]) * 2),
                    cv=cv_obj, scoring=metric,
                    random_state=42, n_jobs=-1, refit=True,
                )
                search.fit(X_train, y_train)
            pipe        = search.best_estimator_
            best_params = search.best_params_
            cv_score    = round(search.best_score_, 4)
            console.print(f"[green]✓ Tuning complete — best CV score: {cv_score:.4f}[/green]")

        train_score = pipe.score(X_train, y_train)
        test_score  = pipe.score(X_test,  y_test)

        metrics = self._compute_metrics(pipe, X_test, y_test, task)
        result = TrainResult(
            model_name=bm.best_name, task=task,
            train_score=round(train_score, 4), test_score=round(test_score, 4),
            metrics=metrics, pipeline=pipe, label_encoder=le,
            feature_names=list(X.columns),
            cv_score=cv_score, cv_std=cv_std, best_params=best_params,
        )
        result.display()
        return result

    def evaluate(
        self,
        pipeline: Any,
        X_test: pd.DataFrame,
        y_test: pd.Series,
        task: Optional[str] = None,
    ) -> Dict[str, float]:
        if task is None:
            task = detect_task_type(y_test)
        metrics = self._compute_metrics(pipeline, X_test, y_test, task)
        console.print("[bold cyan]Evaluation Metrics[/bold cyan]")
        for k, v in metrics.items():
            console.print(f"  {k}: [bold]{v:.4f}[/bold]")
        return metrics

    # ------------------------------------------------------------------ #
    # Internal helpers                                                     #
    # ------------------------------------------------------------------ #

    def _prepare(self, df, target) -> Tuple[pd.DataFrame, pd.Series, str, Optional[LabelEncoder]]:
        df = df.copy()
        y = df[target].dropna()
        df = df.loc[y.index]
        X = df.drop(columns=[target])
        X = X.apply(pd.to_numeric, errors="ignore")

        task = detect_task_type(y)
        le = None
        if task == "classification" and y.dtype == "object":
            le = LabelEncoder()
            y = pd.Series(le.fit_transform(y), index=y.index, name=target)

        return X, y, task, le

    def _build_preprocessor(self, X: pd.DataFrame) -> ColumnTransformer:
        num = get_numeric_cols(X)
        cat = get_categorical_cols(X)
        transformers = []
        if num:
            transformers.append(("num", StandardScaler(), num))
        if cat:
            transformers.append(("cat", self._make_ohe(), cat))
        if not transformers:
            raise ValueError("No usable feature columns found.")
        return ColumnTransformer(transformers, remainder="drop")

    @staticmethod
    def _make_ohe() -> OneHotEncoder:
        """Build OneHotEncoder compatible with sklearn 1.1+ and 1.2+."""
        try:
            # sparse_output added in sklearn 1.2
            return OneHotEncoder(handle_unknown="ignore", max_categories=50, sparse_output=False)
        except TypeError:
            try:
                # max_categories added in sklearn 1.1; sparse renamed in 1.2
                return OneHotEncoder(handle_unknown="ignore", max_categories=50, sparse=False)
            except TypeError:
                return OneHotEncoder(handle_unknown="ignore", sparse=False)

    @staticmethod
    def _select_metric(task: str, y: pd.Series) -> str:
        """Use F1-weighted for imbalanced classification; accuracy for balanced; R2 for regression."""
        if task != "classification":
            return "r2"
        counts = y.value_counts(normalize=True)
        if len(counts) >= 2 and counts.iloc[-1] < 0.20:
            return "f1_weighted"
        return "accuracy"

    def _get_models(self, task: str, y: pd.Series, extra_models: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        imbalanced = False
        if task == "classification":
            counts = y.value_counts(normalize=True)
            imbalanced = len(counts) > 1 and counts.iloc[-1] < 0.15

        models: Dict[str, Any] = {}
        if task == "classification":
            cw = "balanced" if imbalanced else None
            models["LogisticRegression"] = LogisticRegression(
                max_iter=1000, class_weight=cw, random_state=42
            )
            models["RandomForest"] = RandomForestClassifier(
                n_estimators=100, class_weight=cw, random_state=42
            )
            models["GradientBoosting"] = GradientBoostingClassifier(
                n_estimators=100, random_state=42
            )
        else:
            models["Ridge"] = Ridge()  # Ridge is deterministic; no random_state
            models["RandomForest"] = RandomForestRegressor(n_estimators=100, random_state=42)
            models["GradientBoosting"] = GradientBoostingRegressor(
                n_estimators=100, random_state=42
            )

        # Optional XGBoost
        try:
            import xgboost as xgb
            if task == "classification":
                models["XGBoost"] = xgb.XGBClassifier(
                    tree_method="hist", random_state=42,
                    eval_metric="logloss",
                    # use_label_encoder removed in XGBoost 2.0
                )
            else:
                models["XGBoost"] = xgb.XGBRegressor(tree_method="hist", random_state=42)
        except ImportError:
            pass

        # Optional LightGBM
        try:
            import lightgbm as lgb
            if task == "classification":
                models["LightGBM"] = lgb.LGBMClassifier(random_state=42, verbose=-1)
            else:
                models["LightGBM"] = lgb.LGBMRegressor(random_state=42, verbose=-1)
        except ImportError:
            pass

        if extra_models:
            models.update(extra_models)

        return models

    def _compute_metrics(self, pipe, X_test, y_test, task) -> Dict[str, float]:
        y_pred = pipe.predict(X_test)
        if task == "classification":
            metrics: Dict[str, float] = {
                "accuracy": accuracy_score(y_test, y_pred),
            }
            try:
                n_classes = len(np.unique(y_test))
                avg = "binary" if n_classes == 2 else "weighted"
                metrics["f1"] = f1_score(y_test, y_pred, average=avg, zero_division=0)
                if hasattr(pipe, "predict_proba"):
                    proba = pipe.predict_proba(X_test)
                    if n_classes == 2:
                        metrics["roc_auc"] = roc_auc_score(y_test, proba[:, 1])
                    else:
                        metrics["roc_auc"] = roc_auc_score(
                            y_test, proba, multi_class="ovr", average="weighted"
                        )
            except Exception:
                pass
        else:
            metrics = {
                "r2": r2_score(y_test, y_pred),
                "mae": mean_absolute_error(y_test, y_pred),
            }
        return {k: round(v, 4) for k, v in metrics.items()}


# ------------------------------------------------------------------ #
# Module-level convenience API
# ------------------------------------------------------------------ #
_trainer = ModelTrainer()


def benchmark(
    df: pd.DataFrame, target: str, cv: int = 5,
    extra_models: Optional[Dict[str, Any]] = None,
) -> BenchmarkResult:
    return _trainer.benchmark(df, target, cv=cv, extra_models=extra_models)


def train_best(
    df: pd.DataFrame, target: str,
    test_size: float = 0.2, cv: int = 5,
    tune: bool = False, n_iter: int = 20,
    extra_models: Optional[Dict[str, Any]] = None,
) -> TrainResult:
    return _trainer.train_best(
        df, target, test_size=test_size, cv=cv,
        tune=tune, n_iter=n_iter, extra_models=extra_models,
    )


def evaluate(
    pipeline: Any,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    task: Optional[str] = None,
) -> Dict[str, float]:
    return _trainer.evaluate(pipeline, X_test, y_test, task=task)
