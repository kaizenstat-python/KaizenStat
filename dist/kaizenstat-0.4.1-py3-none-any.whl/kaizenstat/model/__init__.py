"""
model — Model benchmarking and training module.

Usage::

    from kaizenstat import model

    result = model.benchmark(df, target="y")
    result = model.train_best(df, target="y")
    metrics = model.evaluate(pipeline, X_test, y_test)
"""
from .trainer import (
    ModelTrainer,
    BenchmarkResult,
    TrainResult,
    ModelEntry,
    benchmark,
    train_best,
    evaluate,
)

__all__ = [
    "ModelTrainer",
    "BenchmarkResult",
    "TrainResult",
    "ModelEntry",
    "benchmark",
    "train_best",
    "evaluate",
]
