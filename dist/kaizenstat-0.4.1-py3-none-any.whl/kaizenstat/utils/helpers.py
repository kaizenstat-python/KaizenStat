"""Shared utility functions used across all KaizenStat modules."""
from __future__ import annotations

import warnings
from typing import List, Optional

import numpy as np
import pandas as pd


def detect_task_type(y: pd.Series) -> str:
    """Return 'classification' or 'regression' from target series."""
    if y.dtype == "object" or y.dtype.name == "category":
        return "classification"
    if np.issubdtype(y.dtype, np.floating):
        return "regression"
    if np.issubdtype(y.dtype, np.integer) and y.nunique() <= 20:
        return "classification"
    return "regression"


def get_numeric_cols(df: pd.DataFrame, exclude: Optional[List[str]] = None) -> List[str]:
    cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if exclude:
        cols = [c for c in cols if c not in exclude]
    return cols


def get_categorical_cols(df: pd.DataFrame, exclude: Optional[List[str]] = None) -> List[str]:
    cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    if exclude:
        cols = [c for c in cols if c not in exclude]
    return cols


def score_to_grade(score: float) -> str:
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


def risk_to_color(risk: str) -> str:
    mapping = {"LOW": "green", "MEDIUM": "yellow", "HIGH": "red", "CRITICAL": "bold red"}
    return mapping.get(risk.upper(), "white")


def validate_dataframe(df: pd.DataFrame, target: Optional[str] = None) -> None:
    if df is None or not isinstance(df, pd.DataFrame):
        raise TypeError("Input must be a pandas DataFrame.")
    if df.empty:
        raise ValueError("DataFrame is empty.")
    if target and target not in df.columns:
        raise ValueError(
            f"Target column '{target}' not found. "
            f"Available columns: {list(df.columns)}"
        )
    if len(df) < 5:
        warnings.warn("DataFrame has fewer than 5 rows — results may be unreliable.", stacklevel=3)


def detect_id_columns(df: pd.DataFrame) -> List[str]:
    """Detect columns that look like row IDs or unique identifiers."""
    id_patterns = {"id", "uuid", "index", "key", "serial", "row_num", "rowid"}
    id_cols = []
    for col in df.columns:
        col_lower = col.lower().strip()
        if col_lower in id_patterns or col_lower.endswith("_id") or col_lower.startswith("id_"):
            id_cols.append(col)
            continue
        if df[col].dtype == "object" or np.issubdtype(df[col].dtype, np.integer):
            if df[col].nunique() > len(df) * 0.95 and len(df) > 20:
                id_cols.append(col)
    return id_cols
