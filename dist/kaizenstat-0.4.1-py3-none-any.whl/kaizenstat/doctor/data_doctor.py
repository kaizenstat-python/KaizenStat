"""DataDoctor — the primary sklearn-style orchestrator for the KaizenStat pipeline."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

import pandas as pd
from rich.console import Console
from rich.panel import Panel

from kaizenstat.debug.debugger import ModelDebugger
from kaizenstat.fix.engine import FixEngine
from kaizenstat.health.scorer import HealthResult, HealthScorer
from kaizenstat.improve.suggester import ImprovementReport, Suggester
from kaizenstat.model.trainer import ModelTrainer, TrainResult
from kaizenstat.output.reporter import Reporter
from kaizenstat.utils.helpers import detect_task_type, validate_dataframe
from kaizenstat.validate.checker import ValidationReport, Validator

console = Console()


@dataclass
class ComparisonResult:
    """Before-vs-after result from auto_improve()."""
    before: TrainResult
    after: TrainResult

    @property
    def score_delta(self) -> float:
        return round(self.after.test_score - self.before.test_score, 4)

    def display(self) -> None:
        delta = self.score_delta
        color = "green" if delta > 0 else ("red" if delta < 0 else "dim")
        console.print(Panel.fit(
            f"[bold]Before[/bold]  {self.before.model_name:20s}  Test: {self.before.test_score:.4f}\n"
            f"[bold]After[/bold]   {self.after.model_name:20s}  Test: {self.after.test_score:.4f}\n"
            f"[bold]Delta[/bold]   [{color}]{delta:+.4f}[/{color}]"
            + (f"  ({'improved' if delta > 0 else 'no gain'})" if delta != 0 else "  (no change)"),
            title="[bold]KaizenStat · Before vs After[/bold]",
            border_style=color,
        ))


class DataDoctor:
    """
    KaizenStat's primary interface — mirrors the sklearn API style.

    Typical workflow::

        doctor = DataDoctor()
        doctor.fit(df, target="survived")
        doctor.health()
        doctor.validate()
        doctor.fix(safe=True)
        doctor.train()
        doctor.debug_model()
        doctor.improve()
        doctor.report()
    """

    def __init__(self) -> None:
        self._df: Optional[pd.DataFrame] = None
        self._target: Optional[str] = None
        self._fixed_df: Optional[pd.DataFrame] = None

        # Pipeline results (populated lazily)
        self._health_result: Optional[HealthResult] = None
        self._validation_result: Optional[ValidationReport] = None
        self._train_result: Optional[TrainResult] = None
        self._debug_result = None
        self._improvement_report: Optional[ImprovementReport] = None

        # Plugin registries
        self._custom_models: Dict[str, Any] = {}
        self._custom_checks: List[Callable] = []

        # Module instances
        self._scorer = HealthScorer()
        self._validator = Validator()
        self._fix_engine = FixEngine()
        self._trainer = ModelTrainer()
        self._debugger = ModelDebugger()
        self._suggester = Suggester()
        self._reporter = Reporter()

    # ------------------------------------------------------------------ #
    # 1. fit                                                               #
    # ------------------------------------------------------------------ #

    def fit(self, df: pd.DataFrame, target: Optional[str] = None) -> "DataDoctor":
        """
        Register a dataset with the doctor.

        Args:
            df:     Input pandas DataFrame.
            target: Name of the target column (required for supervised tasks).
        """
        validate_dataframe(df, target)
        self._df = df.copy()
        self._target = target
        self._fixed_df = None

        # Reset cached results when re-fit
        self._health_result = None
        self._validation_result = None
        self._train_result = None
        self._debug_result = None
        self._improvement_report = None

        rows, cols = df.shape
        task_str = ""
        if target:
            task = detect_task_type(df[target].dropna())
            task_str = f"  │  Task: {task}"

        console.print(Panel.fit(
            f"[bold cyan]Dataset registered[/bold cyan]  "
            f"│  {rows:,} rows × {cols} columns{task_str}",
            title="[bold]DataDoctor.fit[/bold]",
            border_style="cyan",
        ))
        return self

    # ------------------------------------------------------------------ #
    # 2. health                                                            #
    # ------------------------------------------------------------------ #

    def health(self) -> HealthResult:
        """Compute and display the Data Health Score (0–100)."""
        self._require_fit()
        self._health_result = self._scorer.report(self._active_df, self._target)
        return self._health_result

    # ------------------------------------------------------------------ #
    # 3. validate                                                          #
    # ------------------------------------------------------------------ #

    def validate(self) -> ValidationReport:
        """Run statistical assumption and leakage checks (plus any registered custom checks)."""
        self._require_fit()
        self._validation_result = self._validator.assumptions(self._active_df, self._target)
        for label, fn in self._custom_checks:
            try:
                issues = fn(self._active_df, self._target)
                if issues:
                    console.print(f"[yellow]Custom check '[bold]{label}[/bold]':[/yellow]")
                    for iss in issues:
                        console.print(f"  • {iss}")
            except Exception as exc:
                console.print(f"[red]Custom check '{label}' raised: {exc}[/red]")
        self._validation_result.display()
        return self._validation_result

    # ------------------------------------------------------------------ #
    # 4. fix                                                               #
    # ------------------------------------------------------------------ #

    def fix(self, safe: bool = True, preview_only: bool = False) -> pd.DataFrame:
        """
        Show (and optionally apply) safe data corrections.

        Args:
            safe:         If True, only apply LOW-risk fixes.
            preview_only: If True, show the plan but do not apply it.

        Returns:
            Fixed DataFrame (or original if preview_only=True).
        """
        self._require_fit()
        plan = self._fix_engine.plan(self._active_df, self._target, safe=safe)
        if preview_only:
            return self._active_df
        self._fixed_df = plan.apply(self._active_df)
        return self._fixed_df

    # ------------------------------------------------------------------ #
    # 5. train                                                             #
    # ------------------------------------------------------------------ #

    def train(self, cv: int = 5, test_size: float = 0.2, tune: bool = False, n_iter: int = 20) -> TrainResult:
        """
        Benchmark models and train the best one.

        Args:
            cv:        Number of cross-validation folds.
            test_size: Fraction held out for the final test set.
            tune:      If True, run RandomizedSearchCV on the best model.
            n_iter:    Number of random hyperparameter combinations to try when tune=True.
        """
        self._require_fit()
        if not self._target:
            raise ValueError("A target column is required for training. Call fit(df, target=...).")
        self._train_result = self._trainer.train_best(
            self._active_df, self._target,
            test_size=test_size, cv=cv, tune=tune, n_iter=n_iter,
            extra_models=self._custom_models or None,
        )
        return self._train_result

    # ------------------------------------------------------------------ #
    # 6. debug_model                                                       #
    # ------------------------------------------------------------------ #

    def debug_model(self, test_size: float = 0.2) -> Any:
        """
        Diagnose why the model is failing.

        Requires train() to have been called first, or will run it automatically.
        """
        self._require_fit()
        if not self._target:
            raise ValueError("A target column is required for model debugging.")
        if self._train_result is None:
            console.print("[dim]Running train() first...[/dim]")
            self.train(test_size=test_size)

        from sklearn.model_selection import train_test_split

        df = self._active_df.copy()

        # Drop rows with missing target to avoid stratify / scoring errors
        df = df.loc[df[self._target].notna()].copy()

        X = df.drop(columns=[self._target])
        y = df[self._target]

        task = detect_task_type(y)

        # Apply the same LabelEncoding the trainer used so pipeline scores are correct
        le = self._train_result.label_encoder
        if le is not None:
            y = pd.Series(le.transform(y), index=y.index, name=self._target)

        try:
            stratify = y if task == "classification" else None
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, stratify=stratify, random_state=42
            )
        except ValueError:
            # Fallback when a class has too few samples to stratify
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, random_state=42
            )

        pipe = self._train_result.pipeline
        self._debug_result = self._debugger.model_failure(pipe, X_train, X_test, y_train, y_test)
        return self._debug_result

    # ------------------------------------------------------------------ #
    # 7. improve                                                           #
    # ------------------------------------------------------------------ #

    def improve(self) -> ImprovementReport:
        """Generate prioritised improvement suggestions from all pipeline stages."""
        self._require_fit()
        self._improvement_report = self._suggester.suggest(
            self._active_df,
            target=self._target,
            health_result=self._health_result,
            debug_result=self._debug_result,
            validation_result=self._validation_result,
        )
        return self._improvement_report

    # ------------------------------------------------------------------ #
    # 8. report                                                            #
    # ------------------------------------------------------------------ #

    def report(
        self,
        output_path: str = "kaizenstat_report.html",
        open_browser: bool = False,
    ) -> str:
        """
        Print a terminal summary and export an HTML report.

        Args:
            output_path:  File path for the HTML output.
            open_browser: Automatically open the report in a browser.

        Returns:
            Path to the generated HTML file.
        """
        self._require_fit()
        self._reporter.summary(
            health_result=self._health_result,
            validation_result=self._validation_result,
            train_result=self._train_result,
            debug_result=self._debug_result,
            improvement_report=self._improvement_report,
        )
        results = {
            "health": self._health_result,
            "validation": self._validation_result,
            "train": self._train_result,
            "debug": self._debug_result,
            "improvements": self._improvement_report,
        }
        return self._reporter.html(results, path=output_path, open_browser=open_browser)

    # ------------------------------------------------------------------ #
    # 9. auto_improve                                                      #
    # ------------------------------------------------------------------ #

    def auto_improve(self, tune: bool = True) -> "ComparisonResult":
        """
        Detect issues, apply safe fixes, retrain, and compare before vs after.

        Returns a ComparisonResult with score_delta showing the improvement.
        """
        self._require_fit()

        console.print(Panel.fit(
            "[bold cyan]Step 1/3[/bold cyan] — Baseline training",
            border_style="cyan",
        ))
        if self._train_result is None:
            self.train(tune=False)
        baseline = self._train_result

        console.print(Panel.fit(
            "[bold cyan]Step 2/3[/bold cyan] — Applying safe data fixes",
            border_style="cyan",
        ))
        self.fix(safe=True)

        console.print(Panel.fit(
            f"[bold cyan]Step 3/3[/bold cyan] — Retraining"
            + (" with hyperparameter tuning" if tune else ""),
            border_style="cyan",
        ))
        self._train_result = None  # force retrain on fixed data
        self.train(tune=tune)
        improved = self._train_result

        result = ComparisonResult(before=baseline, after=improved)
        result.display()
        return result

    # ------------------------------------------------------------------ #
    # 10. pipeline_confidence                                              #
    # ------------------------------------------------------------------ #

    def pipeline_confidence(self) -> int:
        """
        Compute a 0–100 Pipeline Confidence Score based on health, validation,
        model stability, and test performance.
        """
        self._require_fit()
        score = 50

        if self._health_result is not None:
            score += int(self._health_result.score * 0.25)

        if self._validation_result is not None:
            n_issues = len(self._validation_result.issues)
            score -= min(20, n_issues * 5)

        if self._train_result is not None:
            score += int(self._train_result.test_score * 20)

        if self._debug_result is not None:
            gap = abs(self._debug_result.gap)
            score -= min(20, int(gap * 100))

        score = max(0, min(100, score))
        color = "green" if score >= 80 else ("yellow" if score >= 60 else "red")
        grade = "production-ready" if score >= 80 else ("needs work" if score >= 60 else "not ready")
        console.print(Panel.fit(
            f"[bold {color}]{score}% — {grade}[/bold {color}]",
            title="[bold]KaizenStat · Pipeline Confidence Score[/bold]",
            border_style=color,
        ))
        return score

    # ------------------------------------------------------------------ #
    # Plugin API                                                           #
    # ------------------------------------------------------------------ #

    def add_model(self, name: str, model: Any) -> "DataDoctor":
        """Register a custom model to include in the benchmark.

        Example::

            from sklearn.svm import SVC
            doctor.add_model("SVM", SVC(probability=True))
        """
        self._custom_models[name] = model
        console.print(f"[green]✓ Model '[bold]{name}[/bold]' registered — will compete in next benchmark.[/green]")
        return self

    def add_check(self, check_fn: Callable, name: str = "") -> "DataDoctor":
        """Register a custom validation check function.

        The function receives ``(df, target)`` and should return a list of
        issue strings (empty list = no issues).

        Example::

            def my_check(df, target):
                if df[target].nunique() < 2:
                    return ["Target has fewer than 2 classes"]
                return []

            doctor.add_check(my_check, name="target_classes")
        """
        label = name or getattr(check_fn, "__name__", "custom_check")
        self._custom_checks.append((label, check_fn))
        console.print(f"[green]✓ Check '[bold]{label}[/bold]' registered — will run in next validate().[/green]")
        return self

    # ------------------------------------------------------------------ #
    # Convenience pass-throughs                                            #
    # ------------------------------------------------------------------ #

    def export_model(self, path: str = "model.joblib") -> str:
        """Export the trained model pipeline to disk."""
        if self._train_result is None:
            raise RuntimeError("No trained model found. Call train() first.")
        return self._reporter.export_model(self._train_result.pipeline, path=path)

    def codegen(self, output_path: str = "pipeline.py") -> str:
        """Generate a standalone Python script reproducing the pipeline."""
        self._require_fit()
        task = ""
        if self._target and self._train_result:
            task = self._train_result.task
        return self._reporter.codegen(
            self._active_df, self._target, output_path=output_path, task=task
        )

    # ------------------------------------------------------------------ #
    # Internal                                                             #
    # ------------------------------------------------------------------ #

    @property
    def _active_df(self) -> pd.DataFrame:
        return self._fixed_df if self._fixed_df is not None else self._df

    def _require_fit(self) -> None:
        if self._df is None:
            raise RuntimeError(
                "DataDoctor has not been fitted. Call doctor.fit(df, target='...') first."
            )

    def __repr__(self) -> str:
        fitted = self._df is not None
        target = f", target='{self._target}'" if self._target else ""
        shape = f", shape={self._df.shape}" if fitted else ""
        return f"DataDoctor(fitted={fitted}{shape}{target})"
